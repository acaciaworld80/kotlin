package com.acacia.matasano_level1

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import kotlinx.android.synthetic.main.activity_challenge1.*

class challenge1 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_challenge1)

        convert.setOnClickListener {
            val raw_value = base_hex().hex_to_raw(question1.text.toString()) //convert hex to raw value
            Log.d("raw_value",raw_value) //show the real value using log function

            val base64_encode = base_hex().raw_to_base64(raw_value) // convert the raw value to base64
            Log.d("base64_value",base64_encode) //show the base64 value to log function

            result.setText(base64_encode) //show the function to screen
        }

    }
}
