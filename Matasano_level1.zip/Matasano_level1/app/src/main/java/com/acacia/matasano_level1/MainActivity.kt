package com.acacia.matasano_level1

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        chall_1.setOnClickListener {
            val move_chall1 = Intent(this,challenge1::class.java)
            startActivity(move_chall1)
        }

        chall_2.setOnClickListener {
            val move_chall2 = Intent(this,challenge2::class.java)
            startActivity(move_chall2)
        }
    }
}
