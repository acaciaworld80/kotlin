package com.acacia.matasano_level1

import java.util.*
import android.util.Base64

class base_hex{

    fun hex_to_raw(hex_value:String):String{

        var raw = "";

        for(x in 0 until hex_value.length step 2){
            var temp = hex_value.subSequence(x,x+2)
            raw += temp.toString().toInt(16).toChar()

        }
        return raw
    }

    fun raw_to_base64(raw:String):String{
        var byte_raw = raw.toByteArray()
        var encodedstring = Base64.encodeToString(byte_raw,Base64.DEFAULT)

        return encodedstring

    }

    fun raw_to_hex(raw:Int):String{
        return raw.toString(16)

    }

}