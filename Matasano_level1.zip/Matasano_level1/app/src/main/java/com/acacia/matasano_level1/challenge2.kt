package com.acacia.matasano_level1

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_challenge2.*

class challenge2 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_challenge2)

        convert.setOnClickListener {
            val xor_1 = xor_1.text.toString()
            val xor_2 = xor_2.text.toString()

            var result_fixed_xor = ""

            for(x in 0 until xor_1.length step 2){
                var temp1 = xor_1.subSequence(x,x+2)
                var temp2 = xor_2.subSequence(x,x+2)

                var temp_result = temp1.toString().toInt(16) xor temp2.toString().toInt(16)
                result_fixed_xor += base_hex().raw_to_hex(temp_result)
            }

            result.setText(result_fixed_xor)
        }
    }
}
