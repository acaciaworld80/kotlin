package com.example.kotlin_1

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    //in this app i will show you how to do set button and use intent to invoke activity in kotlin

    //SET BUTTON:
    //1. create button inside the activity_main.xml file
    //  a. remember to set the id of the android button (go to the activity_main.xml file)
    //2. go to mainactivity.kt type the name the id of the button and include "setOnClickListener{}"
    //3. inside the "setOnClickListener" method put another method so it will trigger an event"

    //GET MESSAGE FROM USER:
    //1. To get the message from user you need to declare a variable to uses as an container for the input and
    // get it using .text.toString() method

    //USE INTENT without value
    //1. initialize variable kotlin and assign intent object to it. the intent method require two param
    // first is the source (this)
    // second is the destination, use the reflection of kotlin to refer the target activity (<class name>::class.java)
    //2. start the intent by using startActivity method :)

    //USE INTENT with value
    //1. using the intent object method .putExtra to send data to other activity and the method require two param
    // first is the key for matching the destination
    // second is the data that was transferred
    //2. in the target activity that will receive the data you have to create a value again that contain intent object
    // with extras method
    //3. create another variable that will contain the data from the intent



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //2 & 3 (SET BUTTON)
        click_me.setOnClickListener{
            Log.d("activity","senpai you click me :)");
            Toast.makeText(this,"senpai you click me",Toast.LENGTH_LONG).show();
        }

        submit.setOnClickListener {
            val message:String = username.text.toString(); //1 (GET MESSAGE FROM USER)
            Toast.makeText(this,message,Toast.LENGTH_LONG).show();

            val intent_move_without_data = Intent(this, Called_activity::class.java); //1.(USE INTENT)

            intent_move_without_data.putExtra("key",message);// 1.(USE INTENT with value)

            startActivity(intent_move_without_data);//2.(USE INTENT)
        }

        implicit.setOnClickListener {
            val message:String = username.text.toString();

            val intent_implicit = Intent(); //param is empty because we dont know which app we want to send
            intent_implicit.action = Intent.ACTION_SEND; //set the action to be ACTION_SEND so the data can be passed
            intent_implicit.putExtra(Intent.EXTRA_TEXT,message);// put the data to the intent use EXTRA_TEXT for predefine key
            intent_implicit.type = "text/plain" //choose the type

            startActivity(Intent.createChooser(intent_implicit,"share to:"))
        }


    }
}
